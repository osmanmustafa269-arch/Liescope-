@echo off
cd /d %~dp0
py -m pip install -r requirements.txt
echo.
echo LieScope will be available to devices on the same Wi-Fi at http://YOUR-PC-IP:8000
echo Keep this window open. Windows Firewall may ask for permission; allow Private networks.
py -m uvicorn app:app --host 0.0.0.0 --port 8000
pause

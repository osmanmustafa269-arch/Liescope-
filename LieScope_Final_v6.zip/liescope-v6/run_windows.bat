@echo off
cd /d %~dp0
py -m pip install -r requirements.txt
start "" http://localhost:8000
py -m uvicorn app:app --host 127.0.0.1 --port 8000
pause
